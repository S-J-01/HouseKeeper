node-aREST-example
==================

Example for the Node.js aREST module
